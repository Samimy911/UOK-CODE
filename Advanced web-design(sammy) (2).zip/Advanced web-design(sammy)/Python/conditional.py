num=int(input("Enter a number "))


if num>0:
    print("This is positive number")


elif num<0:
    print("This is negative number ")


else:
     print("You have entered an invalid number or character")