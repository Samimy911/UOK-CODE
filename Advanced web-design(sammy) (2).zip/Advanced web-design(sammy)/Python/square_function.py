def sqquare(x):
    return x*x

for i in range(10):

    print(i)